import { Component, OnInit } from '@angular/core';
import { TestService } from './test.service';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private ser:TestService){}
  title = 'TodoApp';
  todo:any=[];
msg:string
  ngOnInit()
  {
    this.ser.getList().subscribe(data => 
      this.todo=data
      )
  }
 

   addTodo(newTodoLabel):number{
     var newTodo = {
       label:newTodoLabel,
       priority:1,
       done:false
     };
     this.ser.addToList(newTodo)
    var result= this.todo.push(newTodo);
    console.log("result :"+result);
    return result;
   }
   deleteTodo(newTodo){
     this.todo=this.todo.filter(t => t.label !== newTodo.label);
      return this.todo.length
   }
}