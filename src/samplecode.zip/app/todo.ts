export class Todo{
    label:string;
    priority:number;
    done:boolean
}